package com.bignerdranch.android.tingle.Model.UnitTests;

import junit.framework.TestCase;

/**
 * This test class should be used to test that the Thing data model is correct.
 */
public class ThingTest extends TestCase {

    public void testToString() throws Exception {

    }

    public void testOneLine() throws Exception {

    }

    public void testSetWhat() throws Exception {

    }

    public void testGetWhere() throws Exception {

    }

    public void testSetWhere() throws Exception {

    }

    public void testGetId() throws Exception {

    }
}