package com.bignerdranch.android.tingle.Model.UnitTests;

import junit.framework.TestCase;

/**
 * This test class should be used to test the functionalities of the repository used to CRUD Things.
 */
public class ThingRepositoryTest extends TestCase {

    public void testGet() throws Exception {

    }

    public void testGetAll() throws Exception {

    }

    public void testGetThings() throws Exception {

    }

    public void testAddThing() throws Exception {

    }

    public void testRemoveThing() throws Exception {

    }

    public void testSize() throws Exception {

    }

    public void testGet1() throws Exception {

    }

    public void testGetThing() throws Exception {

    }
}